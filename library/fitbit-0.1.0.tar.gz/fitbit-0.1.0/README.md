python-fitbit
=============

[![Build Status](https://travis-ci.org/orcasgit/python-fitbit.png?branch=master)](https://travis-ci.org/orcasgit/python-fitbit)
[![Coverage Status](https://coveralls.io/repos/orcasgit/python-fitbit/badge.png?branch=master)](https://coveralls.io/r/orcasgit/python-fitbit?branch=master)
[![Requirements Status](https://requires.io/github/orcasgit/python-fitbit/requirements.png?branch=master)](https://requires.io/github/orcasgit/python-fitbit/requirements/?branch=master)

Fitbit API Python Client Implementation

For documentation: [http://python-fitbit.readthedocs.org/](http://python-fitbit.readthedocs.org/)

Requirements
============

* Python 2.6+  
